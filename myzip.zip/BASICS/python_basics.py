print("*"*10)

#variables
count = 1000
is_count = True
rating = 4.5
print(type(rating))
print(type(is_count))

#strings
course = 'python programming'
print(len(course))
print(course[0:18])
print(course[0:18:2])
print(course[::-1])#reverse string
print(course[:5])

#escape character:\,\',\",\\
course2 = "machine learning basic's"
print(len(course2))#length of string
print(course.upper())#convert string in uppercase also Lower() for lowercase
print(course.replace("p","j"))

#numbers
x = 10
print(x+2)
print(x*2)
print(x/2)
print(x-2)
print(x**2)

#increment in variable
x = x + 2
print(x)
 
#built in function for numbers
import math
print(math.floor(3.25))
print(round(3.78))
print(abs(-4.5))

